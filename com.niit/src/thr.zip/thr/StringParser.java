/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thr;

/**
 *
 * @author admin
 */
public class StringParser {
    
   static String received_query,queryBreaker[],classPath,firstCond,secondCond;
   boolean has_select,has_asterisk,whereExists,groupbyExists,sortbyExists,orderbyExists,byExists,has_sum,has_count;
   
   int query_Length;
   
   //creating object for custom object class
   CustomObject cusObj=new CustomObject();
   
   public void strArray()
    {
        StringInput Input_obj=new StringInput();
        received_query=Input_obj.sendQuery();
        queryBreaker=received_query.split(" ");
        query_Length=received_query.length();
        
    }
   
    
    public void csvParams()
    {
        for(int i = 0;i<queryBreaker.length;i++)
        {
            if(queryBreaker[i].contains(".csv"))
            {
                classPath=queryBreaker[i];
            }
//            if(queryBreaker[i].contains("where"))
//            {
//                secondCond=queryBreaker[i+1];
//            }
//            firstCond=queryBreaker[1];
            
            
        }
        //System.out.println("class path is "+classPath+"first cond is "+firstCond+"second cond is "+secondCond);
    }
  
    public void booleanCheck()
    {
        for(int i=0;i<queryBreaker.length;i++)
            
                {
                    if(queryBreaker[0].contains("select"))
                        {
                            has_select=true;
        }
        if(queryBreaker[1].contains("*"))
        {
            has_asterisk=true;
        }  
        if(queryBreaker[i].contains("where"))
        {
            whereExists=true;
        }
              orderbyExists=received_query.contains("order by");
            sortbyExists=received_query.contains("sort by");
            groupbyExists=received_query.contains("group by");   
            
            
            if(queryBreaker[i].contains("sum"))
        {
            has_sum=true;
        }
        if(queryBreaker[i].contains("count"))
        {
            has_count=true;
        }
                }
        
    }
    
    public boolean inputQuery_checker()
    {
      if(received_query.contains("select")&& received_query.contains("from")||received_query.contains("*")||received_query.contains("where")||received_query.contains("group by")||received_query.contains("sort by")||received_query.contains("order by"))
        {
            return true;
        }    
        else{
        return false;    
        }
    }
    public void send_CSV_params()
    {
        //CustomObject cusObj=new CustomObject(classPath,firstCond,secondCond);
        
       // cusObj.customobject(classPath,firstCond,secondCond);
        cusObj.display();
        cusObj.query_Splitter(received_query);
        
    }
    
    
            
}

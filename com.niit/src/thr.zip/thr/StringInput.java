/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thr;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class StringInput {
//class to receive the query input from the user
    //-------------------------------------------
    /**
     * @param args the command line arguments
     */
    
    public String sendQuery()
    {
        String inputQuery;
    
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the query:-");
        inputQuery=s.nextLine();
        return inputQuery;
    }
    
        
        
        
    public static void main(String[] args) {
        System.out.println("hi dear project.....!");
        StringParser s1=new StringParser();
        s1.strArray();
        s1.csvParams();
        s1.booleanCheck();
        s1.send_CSV_params();
        
    }
    
}
